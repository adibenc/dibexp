package com.recyclerview;

/**
 * Created by Barokah-Amiin on 06/07/2018.
 */

public class Mahasiswa {

    private String nama;
    private String nim;
    private String nohp;
    private int gambar;


    public int getGambar() {
        return gambar;
    }

    public void setGambar(int gambar) {
        this.gambar = gambar;
    }

    public Mahasiswa(String nama, String nim, String nohp) {
        this.nama = nama;
        this.nim = nim;
        this.nohp = nohp;
    }

    public Mahasiswa(String nama, String nim, String nohp, int gambar) {
        this.nama = nama;
        this.nim = nim;
        this.nohp = nohp;
        this.gambar=gambar;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNohp() {
        return nohp;
    }

    public void setNohp(String nohp) {
        this.nohp = nohp;
    }
}
